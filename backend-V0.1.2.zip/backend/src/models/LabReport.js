// Lab Report model
const mongoose = require('mongoose');

const labReportSchema = new mongoose.Schema({
  reportId: {
    type: String,
    unique: true,
    required: true
  },
  patientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Patient',
    required: true
  },
  doctorId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Doctor',
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  },
  testType: {
    type: String,
    required: true
  },
  testResults: {
    type: String,
    required: true
  },
  normalRange: {
    type: String
  },
  interpretation: {
    type: String
  },
  recommendations: {
    type: String
  },
  pdfUrl: String,
  status: {
    type: String,
    enum: ['pending', 'completed'],
    default: 'pending'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('LabReport', labReportSchema);
