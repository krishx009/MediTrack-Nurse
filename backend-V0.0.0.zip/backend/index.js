const express = require("express");
const connectDB = require("./src/config/db");
const cors = require("cors");
const dotenv = require("dotenv");
const path = require("path");

dotenv.config();
connectDB();

const app = express();
// const nurseRoutes = require("./src/routes/nurseRoutes"); // Correct path
app.use(express.json());
app.use(cors());
// MongoDB will now store and serve files, so we don't need static file serving

app.use("/api/nurse", require("./src/routes/nurseRoutes"));
app.use("/api/patient", require("./src/routes/patientRoutes"));
app.use("/api/visit", require("./src/routes/visitRoutes"));

const PORT = 5000;

app.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
