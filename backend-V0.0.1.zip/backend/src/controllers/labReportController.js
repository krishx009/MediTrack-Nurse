// Lab Report operations for nurse backend
// Nurses can only view lab reports and generate PDFs
const LabReport = require('../models/LabReport');
const Patient = require('../models/Patient');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');

// @desc    Get all lab reports with filters
// @route   GET /api/lab-reports
// @access  Private
const getAllLabReports = async (req, res) => {
  try {
    const { status, testType } = req.query;
    
    const filter = {};
    
    if (status) {
      filter.status = status;
    }
    
    if (testType) {
      filter.testType = testType;
    }
    
    // Simply fetch lab reports without populating references to avoid model dependency issues
    const labReports = await LabReport.find(filter)
      .sort({ date: -1 });
      
    res.json(labReports);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get all lab reports for a patient
// @route   GET /api/lab-reports/patient/:patientId
// @access  Private
const getPatientLabReports = async (req, res) => {
  try {
    // Simply fetch lab reports without populating references to avoid model dependency issues
    const labReports = await LabReport.find({ patientId: req.params.patientId })
      .sort({ date: -1 });

    res.json(labReports);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get lab report by ID
// @route   GET /api/lab-reports/:id
// @access  Private
const getLabReportById = async (req, res) => {
  try {
    // Simply fetch lab report without populating references to avoid model dependency issues
    const labReport = await LabReport.findById(req.params.id);

    if (labReport) {
      res.json(labReport);
    } else {
      res.status(404).json({ message: 'Lab report not found' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Helper function to generate PDF
const generateLabReportPDF = async (labReport, patient, doctor) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Count existing lab reports for this patient to determine sequence number
      const labReportCount = await LabReport.countDocuments({ patientId: patient._id });
      // Format sequence number with leading zeros (e.g., 001, 002, etc.)
      const sequenceNumber = (labReportCount + 1).toString().padStart(3, '0');
      // Create new filename format: LABREP-patientId-sequenceNumber
      const fileName = `LABREP-${patient.patientId || 'UNKNOWN'}-${sequenceNumber}.pdf`;
      const filePath = path.join('uploads', 'lab-reports', fileName);
      
      // Create directory if it doesn't exist
      const dir = path.join('uploads', 'lab-reports');
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      // Create PDF document
      const doc = new PDFDocument({ margin: 50 });
      const stream = fs.createWriteStream(filePath);
      
      doc.pipe(stream);
      
      // Add header
      doc.fontSize(20).text('Laboratory Test Report', { align: 'center' });
      doc.moveDown();
      
      // Add doctor info
      doc.fontSize(12).text(`Dr. ${doctor.name}`, { align: 'right' });
      doc.fontSize(10).text(`${doctor.specialization}`, { align: 'right' });
      doc.moveDown();
      
      // Add line
      doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
      doc.moveDown();
      
      // Add patient info
      doc.fontSize(12).text(`Patient: ${patient.name}`);
      doc.fontSize(10).text(`ID: ${patient.patientId}`);
      doc.fontSize(10).text(`Age/Gender: ${patient.age} years / ${patient.gender}`);
      doc.moveDown();
      
      // Add report details
      doc.fontSize(12).text('Test Type:');
      doc.fontSize(10).text(labReport.testType);
      doc.moveDown();
      
      doc.fontSize(12).text('Test Results:');
      doc.fontSize(10).text(labReport.testResults);
      doc.moveDown();
      
      if (labReport.normalRange) {
        doc.fontSize(12).text('Normal Range:');
        doc.fontSize(10).text(labReport.normalRange);
        doc.moveDown();
      }
      
      if (labReport.interpretation) {
        doc.fontSize(12).text('Interpretation:');
        doc.fontSize(10).text(labReport.interpretation);
        doc.moveDown();
      }
      
      if (labReport.recommendations) {
        doc.fontSize(12).text('Recommendations:');
        doc.fontSize(10).text(labReport.recommendations);
        doc.moveDown();
      }
      
      // Add footer
      doc.moveDown(2);
      doc.fontSize(10).text(`Date: ${new Date(labReport.date).toLocaleDateString()}`, { align: 'right' });
      doc.moveDown();
      doc.fontSize(10).text("Doctor's Signature:", { align: 'right' });
      
      // Finalize PDF
      doc.end();
      
      stream.on('finish', () => {
        resolve(`/uploads/lab-reports/${fileName}`);
      });
      
      stream.on('error', (error) => {
        reject(error);
      });
    } catch (error) {
      reject(error);
    }
  });
};

// @desc    Generate PDF for a lab report
// @route   GET /api/lab-reports/:id/pdf
// @access  Private
const generatePDF = async (req, res) => {
  try {
    const labReport = await LabReport.findById(req.params.id);
    
    if (!labReport) {
      return res.status(404).json({ message: 'Lab report not found' });
    }
    
    const patient = await Patient.findById(labReport.patientId);
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }
    
    // Create a placeholder for doctor information since we don't have access to the Doctor model
    const doctor = {
      name: 'Doctor',
      specialization: 'Medical Professional'
    };
    
    const pdfPath = await generateLabReportPDF(labReport, patient, doctor);
    labReport.pdfUrl = pdfPath;
    await labReport.save();
    
    res.json({ message: 'PDF generated successfully', pdfUrl: pdfPath });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

module.exports = {
  getAllLabReports,
  getPatientLabReports,
  getLabReportById,
  generatePDF
};
