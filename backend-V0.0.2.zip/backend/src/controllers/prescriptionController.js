// Prescription operations for nurse backend
// Nurses can only view prescriptions and generate PDFs, no administration capabilities
const Prescription = require('../models/Prescription');
const Patient = require('../models/Patient');
const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const mongoose = require('mongoose');

// @desc    Get all prescriptions for a patient
// @route   GET /api/prescriptions/patient/:patientId
// @access  Private
const getPatientPrescriptions = async (req, res) => {
  try {
    // Simply fetch prescriptions without populating references to avoid model dependency issues
    const prescriptions = await Prescription.find({ patientId: req.params.patientId })
      .sort({ date: -1 });

    res.json(prescriptions);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get prescription by ID
// @route   GET /api/prescriptions/:id
// @access  Private
const getPrescriptionById = async (req, res) => {
  try {
    // Simply fetch prescription without populating references to avoid model dependency issues
    const prescription = await Prescription.findById(req.params.id);

    if (prescription) {
      res.json(prescription);
    } else {
      res.status(404).json({ message: 'Prescription not found' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Note: Administration-related functions have been removed as per requirement

// @desc    Get all prescriptions with filters
// @route   GET /api/prescriptions
// @access  Private
const getAllPrescriptions = async (req, res) => {
  try {
    const { status, administrationStatus } = req.query;
    
    const filter = {};
    
    if (status) {
      filter.status = status;
    }
    
    if (administrationStatus) {
      filter.administrationStatus = administrationStatus;
    }
    
    // Simply fetch prescriptions without populating references to avoid model dependency issues
    const prescriptions = await Prescription.find(filter)
      .sort({ date: -1 });
      
    res.json(prescriptions);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Helper function to generate PDF
const generatePrescriptionPDF = async (prescription, patient, doctor) => {
  return new Promise(async (resolve, reject) => {
    try {
      // Get all prescriptions for this patient to determine sequence number, excluding the current one
      const existingPrescriptions = await Prescription.find({ 
        patientId: patient._id,
        _id: { $ne: prescription._id } // Exclude the current prescription
      });
      
      // Always start from 1 for the first prescription
      const sequenceNumber = (existingPrescriptions.length + 1).toString().padStart(3, '0');
      
      // Add a 'P' prefix to the sequence number as requested
      const formattedSequence = `P${sequenceNumber}`;
      
      // Create new filename format: PRXN-patientId-P[sequenceNumber]
      const fileName = `PRXN-${patient.patientId}-${formattedSequence}.pdf`;
      
      // Create directory if it doesn't exist
      const dir = path.join('uploads', 'prescriptions');
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      // Add current date and timestamp to ensure absolute uniqueness
      const currentDate = new Date();
      const formattedDate = `${currentDate.getFullYear()}${(currentDate.getMonth() + 1).toString().padStart(2, '0')}${currentDate.getDate().toString().padStart(2, '0')}`;
      const timestamp = Date.now();
      // Include both date and timestamp to guarantee no overwriting
      const uniqueFileName = `PRXN-${patient.patientId}-${formattedSequence}-${formattedDate}-${timestamp}.pdf`;
      const filePath = path.join('uploads', 'prescriptions', uniqueFileName);
      
      // Create PDF document
      const doc = new PDFDocument({ margin: 50 });
      const stream = fs.createWriteStream(filePath);
      
      doc.pipe(stream);
      
      // Add header
      doc.fontSize(20).text('Medical Prescription', { align: 'center' });
      doc.moveDown();
      
      // Add doctor info
      doc.fontSize(12).text(`Dr. ${doctor.name}`, { align: 'right' });
      doc.fontSize(10).text(`${doctor.specialization}`, { align: 'right' });
      doc.moveDown();
      
      // Add line
      doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
      doc.moveDown();
      
      // Add patient info
      doc.fontSize(12).text(`Patient: ${patient.name}`);
      doc.fontSize(10).text(`ID: ${patient.patientId}`);
      doc.fontSize(10).text(`Age/Gender: ${patient.age} years / ${patient.gender}`);
      doc.moveDown();
      
      // Add prescription details
      doc.fontSize(12).text('Diagnosis:');
      doc.fontSize(10).text(prescription.diagnosis);
      doc.moveDown();
      
      if (prescription.clinicalNotes) {
        doc.fontSize(12).text('Clinical Notes:');
        doc.fontSize(10).text(prescription.clinicalNotes);
        doc.moveDown();
      }
      
      // Add medications
      doc.fontSize(12).text('Medications:');
      doc.moveDown();
      
      prescription.medications.forEach((med, index) => {
        doc.fontSize(10).text(`${index + 1}. ${med.medicine}`);
        doc.fontSize(9).text(`   Dosage: ${med.dosage}`);
        doc.fontSize(9).text(`   Duration: ${med.duration}`);
        if (med.notes) {
          doc.fontSize(9).text(`   Instructions: ${med.notes}`);
        }
        doc.moveDown(0.5);
      });
      
      if (prescription.specialInstructions) {
        doc.moveDown();
        doc.fontSize(12).text('Special Instructions:');
        doc.fontSize(10).text(prescription.specialInstructions);
      }
      
      if (prescription.followUp) {
        doc.moveDown();
        doc.fontSize(12).text('Follow-up:');
        doc.fontSize(10).text(`After ${prescription.followUp}`);
      }
      
      // Nurse administration info has been removed as per requirement
      
      // Add footer
      doc.moveDown(2);
      doc.fontSize(10).text(`Date: ${new Date(prescription.date).toLocaleDateString()}`, { align: 'right' });
      doc.moveDown();
      doc.fontSize(10).text("Doctor's Signature:", { align: 'right' });
      
      // Finalize PDF
      doc.end();
      
      stream.on('finish', () => {
        resolve(`/uploads/prescriptions/${uniqueFileName}`);
      });
      
      stream.on('error', (error) => {
        reject(error);
      });
    } catch (error) {
      reject(error);
    }
  });
};

// @desc    Generate PDF for a prescription
// @route   GET /api/prescriptions/:id/pdf
// @access  Private
const generatePDF = async (req, res) => {
  try {
    const prescription = await Prescription.findById(req.params.id);
    
    if (!prescription) {
      return res.status(404).json({ message: 'Prescription not found' });
    }
    
    const patient = await Patient.findById(prescription.patientId);
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }
    
    // Create a placeholder for doctor information since we don't have access to the Doctor model
    const doctor = {
      name: 'Doctor',
      specialization: 'Medical Professional'
    };
    
    // Always generate a fresh PDF with the correct sequence number
    // This ensures each prescription has its own unique PDF
    const pdfPath = await generatePrescriptionPDF(prescription, patient, doctor);
    
    // Update the prescription with the PDF URL if it's different
    if (prescription.pdfUrl !== pdfPath) {
      prescription.pdfUrl = pdfPath;
      await prescription.save();
    }
    
    // Return the PDF URL for download
    res.json({ 
      message: 'PDF generated successfully', 
      pdfUrl: pdfPath,
      fileName: pdfPath.split('/').pop() // Extract filename for frontend use
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

module.exports = {
  getPatientPrescriptions,
  getPrescriptionById,
  getAllPrescriptions,
  generatePDF
};
